#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include "CCDefinitions.h"
#include "KnobComponent.h"

class SectionComponent : public juce::Component
{
public:
    SectionComponent(const juce::String& title, juce::Colour ledColour);

    void addKnob(juce::AudioProcessorValueTreeState& apvts, const CCParam& param);
    void addComboBox(juce::AudioProcessorValueTreeState& apvts, const CCParam& param);
    void addToggle(juce::AudioProcessorValueTreeState& apvts, const CCParam& param);

    void setOpen(bool open);
    bool isOpen() const { return _open; }

    // Callback so the editor can relayout when sections collapse/expand
    std::function<void()> onLayoutChanged;

    void paint(juce::Graphics& g) override;
    void resized() override;
    void mouseDown(const juce::MouseEvent& e) override;

    int getDesiredHeight() const;
    static constexpr int kHeaderHeight = 32;

private:
    juce::String _title;
    juce::Colour _ledColour;
    bool _open = true;

    juce::OwnedArray<JT8000Knob> _knobs;
    juce::OwnedArray<juce::ComboBox> _combos;
    juce::OwnedArray<juce::ToggleButton> _toggles;
    juce::OwnedArray<juce::Label> _labels;
    juce::OwnedArray<juce::AudioProcessorValueTreeState::ComboBoxAttachment> _comboAtts;
    juce::OwnedArray<juce::AudioProcessorValueTreeState::ButtonAttachment> _btnAtts;

    struct ControlEntry { juce::Component* comp; int preferredWidth; int preferredHeight; };
    std::vector<ControlEntry> _controls;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(SectionComponent)
};
