#include "SectionComponent.h"

static const juce::Colour kSecBg     (0xff111620);
static const juce::Colour kSecHdrBg  (0xff161c28);
static const juce::Colour kSecBorder (0xff1e2a3e);
static const juce::Colour kTitleCol  (0xffc8d8f4);
static const juce::Colour kChevronCol(0xff3e5070);

SectionComponent::SectionComponent(const juce::String& title, juce::Colour ledColour)
    : _title(title), _ledColour(ledColour) {}

void SectionComponent::addKnob(juce::AudioProcessorValueTreeState& apvts,
                                const CCParam& param)
{
    auto* knob = _knobs.add(new JT8000Knob(param.name));
    knob->setAttachment(apvts, param.id);
    addAndMakeVisible(knob);
    _controls.push_back({ knob, 58, 72 });
}

void SectionComponent::addComboBox(juce::AudioProcessorValueTreeState& apvts,
                                    const CCParam& param)
{
    // Label above the combo
    auto* label = _labels.add(new juce::Label({}, param.name));
    label->setColour(juce::Label::textColourId, juce::Colour(0xff8090b0));
    label->setFont(juce::FontOptions(9.0f));
    addAndMakeVisible(label);

    auto* combo = _combos.add(new juce::ComboBox());

    // Populate with named options from CCParam if available
    if (param.enumNames != nullptr && param.enumCount > 0)
    {
        for (int i = 0; i < param.enumCount; ++i)
            combo->addItem(param.enumNames[i], i + 1);  // JUCE IDs are 1-based
    }
    else
    {
        // Fallback: raw 0-127
        for (int v = 0; v <= 127; ++v)
            combo->addItem(juce::String(v), v + 1);
    }

    combo->setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff0b0e14));
    combo->setColour(juce::ComboBox::textColourId, juce::Colour(0xffffa040));
    combo->setColour(juce::ComboBox::outlineColourId, juce::Colour(0xff1e2a3e));
    addAndMakeVisible(combo);

    _comboAtts.add(new juce::AudioProcessorValueTreeState::ComboBoxAttachment(
        apvts, param.id, *combo));

    _controls.push_back({ combo, 120, 40 });
}

void SectionComponent::addToggle(juce::AudioProcessorValueTreeState& apvts,
                                  const CCParam& param)
{
    auto* toggle = _toggles.add(new juce::ToggleButton(param.name));
    toggle->setColour(juce::ToggleButton::textColourId, juce::Colour(0xff8090b0));
    toggle->setColour(juce::ToggleButton::tickColourId, juce::Colour(0xfff08020));
    addAndMakeVisible(toggle);

    _btnAtts.add(new juce::AudioProcessorValueTreeState::ButtonAttachment(
        apvts, param.id, *toggle));

    _controls.push_back({ toggle, 100, 28 });
}

void SectionComponent::setOpen(bool open)
{
    if (_open == open) return;
    _open = open;

    for (auto& c : _controls)
        c.comp->setVisible(_open);
    for (auto* l : _labels)
        l->setVisible(_open);

    repaint();

    // Notify the editor to relayout all sections
    if (onLayoutChanged)
        onLayoutChanged();
}

int SectionComponent::getDesiredHeight() const
{
    if (!_open) return kHeaderHeight;

    const int pad = 10;
    const int rowH = 76;
    const int availW = juce::jmax(200, getWidth() - 24);
    int x = 0, rows = 1;

    for (const auto& c : _controls)
    {
        if (x + c.preferredWidth > availW && x > 0) { x = 0; rows++; }
        x += c.preferredWidth + 6;
    }

    return kHeaderHeight + pad + rows * rowH + pad;
}

void SectionComponent::paint(juce::Graphics& g)
{
    auto bounds = getLocalBounds();

    g.setColour(kSecBg);
    g.fillRoundedRectangle(bounds.toFloat(), 4.0f);
    g.setColour(kSecBorder);
    g.drawRoundedRectangle(bounds.toFloat().reduced(0.5f), 4.0f, 1.0f);

    auto hdr = bounds.removeFromTop(kHeaderHeight);
    g.setColour(kSecHdrBg);
    g.fillRoundedRectangle(hdr.toFloat(), 4.0f);

    // LED dot
    g.setColour(_ledColour);
    g.fillEllipse((float)hdr.getX() + 12, (float)hdr.getCentreY() - 4, 8, 8);

    // Title
    g.setColour(kTitleCol);
    g.setFont(juce::FontOptions(12.0f, juce::Font::bold));
    g.drawText(_title, hdr.getX() + 28, hdr.getY(), hdr.getWidth() - 50, hdr.getHeight(),
               juce::Justification::centredLeft);

    // Chevron
    g.setColour(kChevronCol);
    g.setFont(juce::FontOptions(14.0f));
    g.drawText(_open ? juce::String(juce::CharPointer_UTF8("\xe2\x96\xbc"))
                     : juce::String(juce::CharPointer_UTF8("\xe2\x96\xb6")),
               hdr.getRight() - 28, hdr.getY(), 20, hdr.getHeight(),
               juce::Justification::centred);
}

void SectionComponent::resized()
{
    if (!_open) return;

    const int startY = kHeaderHeight + 10;
    const int pad    = 12;
    const int rowH   = 76;
    const int availW = getWidth() - 2 * pad;
    int x = pad, y = startY;

    for (size_t ci = 0; ci < _controls.size(); ++ci)
    {
        auto& c = _controls[ci];
        if (x + c.preferredWidth > pad + availW && x > pad)
        {
            x = pad;
            y += rowH;
        }
        c.comp->setBounds(x, y, c.preferredWidth, c.preferredHeight);
        x += c.preferredWidth + 6;
    }

    // Position labels above their combo boxes
    for (int i = 0; i < _combos.size() && i < _labels.size(); ++i)
    {
        auto cb = _combos[i]->getBounds();
        _labels[i]->setBounds(cb.getX(), cb.getY() - 14, cb.getWidth(), 14);
    }
}

void SectionComponent::mouseDown(const juce::MouseEvent& e)
{
    if (e.y < kHeaderHeight)
        setOpen(!_open);
}
