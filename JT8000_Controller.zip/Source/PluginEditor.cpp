#include "PluginEditor.h"

static const juce::Colour kBg       (0xff0b0e14);
static const juce::Colour kHeaderBg (0xff141a28);
static const juce::Colour kBorder   (0xff1e2a3e);
static const juce::Colour kOrange   (0xfff08020);
static const juce::Colour kTextHi   (0xffc8d8f4);
static const juce::Colour kText     (0xff8090b0);

static juce::Colour sectionLed(Section s)
{
    switch (s) {
        case Section::OSC1: case Section::OSC2:       return juce::Colour(0xfff08020u);
        case Section::MIXER:                          return juce::Colour(0xffc0c8d8u);
        case Section::FILTER:                         return juce::Colour(0xff40a0ffu);
        case Section::AMP_ENV:                        return juce::Colour(0xff28ff58u);
        case Section::FILTER_ENV:                     return juce::Colour(0xff40a0ffu);
        case Section::PITCH_ENV: case Section::VELOCITY: return juce::Colour(0xff9040ffu);
        case Section::LFO1: case Section::LFO2:      return juce::Colour(0xfff08020u);
        case Section::FX_EQ: case Section::FX_MOD: case Section::FX_MOD_TUNE:
        case Section::FX_DELAY: case Section::FX_REVERB: case Section::FX_OUTPUT:
                                                      return juce::Colour(0xffff2828u);
        default:                                      return juce::Colour(0xffc0c8d8u);
    }
}

JT8000ControllerEditor::JT8000ControllerEditor(JT8000ControllerProcessor& p)
    : AudioProcessorEditor(p), proc(p)
{
    // Title
    titleLabel.setText("JT-8000", juce::dontSendNotification);
    titleLabel.setColour(juce::Label::textColourId, kOrange);
    titleLabel.setFont(juce::FontOptions(18.0f, juce::Font::bold));
    addAndMakeVisible(titleLabel);

    // MIDI channel
    for (int i = 1; i <= 16; ++i)
        midiChSelector.addItem("Ch " + juce::String(i), i);
    midiChSelector.setSelectedId(proc.midiChannel.load());
    midiChSelector.onChange = [this] { proc.midiChannel.store(midiChSelector.getSelectedId()); };
    midiChSelector.setColour(juce::ComboBox::backgroundColourId, kBg);
    midiChSelector.setColour(juce::ComboBox::textColourId, kTextHi);
    midiChSelector.setColour(juce::ComboBox::outlineColourId, kBorder);
    addAndMakeVisible(midiChSelector);

    // MIDI output device selector
    midiOutSelector.setColour(juce::ComboBox::backgroundColourId, kBg);
    midiOutSelector.setColour(juce::ComboBox::textColourId, kTextHi);
    midiOutSelector.setColour(juce::ComboBox::outlineColourId, kBorder);
    midiOutSelector.onChange = [this] {
        const int sel = midiOutSelector.getSelectedId();
        if (sel <= 0) {
            proc.setMidiOutput(nullptr);
            return;
        }
        auto devices = juce::MidiOutput::getAvailableDevices();
        const int idx = sel - 1;
        if (idx >= 0 && idx < devices.size()) {
            auto out = juce::MidiOutput::openDevice(devices[idx].identifier);
            proc.setMidiOutput(std::move(out));
        }
    };
    addAndMakeVisible(midiOutSelector);
    refreshMidiOutputList();

    // Buttons
    auto style = [](juce::TextButton& b, juce::Colour c) {
        b.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff161c28));
        b.setColour(juce::TextButton::textColourOffId, c);
    };
    style(sendAllBtn, kOrange);
    style(expandBtn, kText);
    style(collapseBtn, kText);

    sendAllBtn.onClick  = [this] { proc.sendAllCCs(); };
    expandBtn.onClick   = [this] { for (auto* s : sections) s->setOpen(true); };
    collapseBtn.onClick = [this] { for (auto* s : sections) s->setOpen(false); };

    addAndMakeVisible(sendAllBtn);
    addAndMakeVisible(expandBtn);
    addAndMakeVisible(collapseBtn);

    // Scrollable content
    viewport.setViewedComponent(&contentPanel, false);
    viewport.setScrollBarsShown(true, false);
    viewport.getVerticalScrollBar().setColour(
        juce::ScrollBar::thumbColourId, juce::Colour(0xff283850));
    addAndMakeVisible(viewport);

    buildSections();

    setSize(1080, 820);
    setResizable(true, true);
    setResizeLimits(400, 400, 1400, 2400);
}

void JT8000ControllerEditor::refreshMidiOutputList()
{
    midiOutSelector.clear(juce::dontSendNotification);
    midiOutSelector.addItem("— No MIDI Output —", -1);

    auto devices = juce::MidiOutput::getAvailableDevices();
    for (int i = 0; i < devices.size(); ++i)
        midiOutSelector.addItem(devices[i].name, i + 1);

    midiOutSelector.setSelectedId(-1, juce::dontSendNotification);
}

void JT8000ControllerEditor::buildSections()
{
    // Create one section per enum value
    for (int s = 0; s < (int)Section::NUM_SECTIONS; ++s)
    {
        auto* sec = sections.add(
            new SectionComponent(sectionNames[s], sectionLed((Section)s)));

        // Wire the relayout callback so collapse/expand resizes properly
        sec->onLayoutChanged = [this] { layoutSections(); };

        contentPanel.addAndMakeVisible(sec);
    }

    // Populate sections from the master param table
    for (int i = 0; i < kNumParams; ++i)
    {
        const auto& p = kAllParams[i];
        auto* sec = sections[(int)p.section];

        if (p.isEnum)
            sec->addComboBox(proc.apvts, p);
        else
            sec->addKnob(proc.apvts, p);
    }
}

void JT8000ControllerEditor::layoutSections()
{
    const int w = viewport.getWidth() - viewport.getScrollBarThickness() - 8;
    int y = 4;

    for (auto* sec : sections)
    {
        const int h = sec->getDesiredHeight();
        sec->setBounds(4, y, w, h);
        y += h + 4;
    }

    contentPanel.setSize(w + 8, y + 4);
}

void JT8000ControllerEditor::paint(juce::Graphics& g)
{
    g.fillAll(kBg);
    g.setColour(kHeaderBg);
    g.fillRect(0, 0, getWidth(), kHeaderHeight);
    g.setColour(kBorder);
    g.drawHorizontalLine(kHeaderHeight - 1, 0.0f, (float)getWidth());
}

void JT8000ControllerEditor::resized()
{
    auto area = getLocalBounds();
    auto hdr = area.removeFromTop(kHeaderHeight).reduced(6, 6);

    titleLabel.setBounds(hdr.removeFromLeft(90));
    collapseBtn.setBounds(hdr.removeFromRight(66));
    expandBtn.setBounds(hdr.removeFromRight(60));
    sendAllBtn.setBounds(hdr.removeFromRight(66));
    midiChSelector.setBounds(hdr.removeFromRight(60));
    midiOutSelector.setBounds(hdr.removeFromRight(juce::jmin(180, hdr.getWidth())));

    viewport.setBounds(area);
    layoutSections();
}
