#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_audio_devices/juce_audio_devices.h>
#include <juce_gui_extra/juce_gui_extra.h>
#include "PluginProcessor.h"
#include "SectionComponent.h"

class JT8000ControllerEditor : public juce::AudioProcessorEditor
{
public:
    JT8000ControllerEditor(JT8000ControllerProcessor&);
    ~JT8000ControllerEditor() override = default;

    void paint(juce::Graphics& g) override;
    void resized() override;

private:
    JT8000ControllerProcessor& proc;

    juce::Label titleLabel;
    juce::ComboBox midiChSelector;
    juce::ComboBox midiOutSelector;    // MIDI output device picker
    juce::TextButton sendAllBtn  { "Send All" };
    juce::TextButton expandBtn   { "Expand" };
    juce::TextButton collapseBtn { "Collapse" };

    juce::Viewport viewport;
    juce::Component contentPanel;

    juce::OwnedArray<SectionComponent> sections;

    void buildSections();
    void layoutSections();
    void refreshMidiOutputList();

    static constexpr int kHeaderHeight = 44;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(JT8000ControllerEditor)
};
