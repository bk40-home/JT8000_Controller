#include "KnobComponent.h"

static const juce::Colour kKnobBody  (0xff141828);
static const juce::Colour kKnobBorder(0xff2e3a50);
static const juce::Colour kArcTrack  (0xff0a1018);
static const juce::Colour kArcFill   (0xfff08020);
static const juce::Colour kDot       (0xffc0c8e0);
static const juce::Colour kLabel     (0xff8090b0);
static const juce::Colour kValue     (0xffffa040);

JT8000Knob::JT8000Knob(const juce::String& label)
    : labelText(label)
{
    slider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    slider.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    slider.setRange(0, 127, 1);
    slider.setDoubleClickReturnValue(true, 64.0);
    slider.addListener(this);
    addAndMakeVisible(slider);
    slider.setAlpha(0.0f);
}

void JT8000Knob::setAttachment(juce::AudioProcessorValueTreeState& apvts,
                                const juce::String& paramID)
{
    attachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(
        apvts, paramID, slider);
}

void JT8000Knob::resized()
{
    slider.setBounds(getLocalBounds());
}

void JT8000Knob::paint(juce::Graphics& g)
{
    const float w = (float)getWidth();
    const float h = (float)getHeight();
    const float knobDiam = juce::jmin(w, h - 26.0f);
    const float cx = w * 0.5f;
    const float cy = knobDiam * 0.5f + 2.0f;
    const float outerR = knobDiam * 0.42f;
    const float innerR = knobDiam * 0.30f;
    const float arcR   = outerR - 2.0f;

    const float norm = static_cast<float>(slider.getValue() / 127.0);

    // The value angle interpolates between start and end
    const float valAngle = kStartAngle + norm * (kEndAngle - kStartAngle);

    // JUCE Path arcs use the rotation parameter as a base rotation.
    // addCentredArc(cx, cy, rx, ry, rotation, startAngle, endAngle, startAsNewSubPath)
    // Angles are measured from the 3 o'clock position, counter-clockwise positive.
    // To get "clockwise from 12 o'clock", we set rotation = 0 and use:
    //   JUCE angle = our angle + pi/2  (rotate 90 deg so 0 = 12 o'clock)
    // But actually JUCE drawArc / addCentredArc already uses clockwise-from-top
    // when rotation=0 if we offset by pi. Let's just use the path correctly:

    const float piHalf = juce::MathConstants<float>::halfPi;

    // Arc track (full 270 degree sweep)
    {
        juce::Path track;
        track.addCentredArc(cx, cy, arcR, arcR, 0.0f,
                            kStartAngle + piHalf, kEndAngle + piHalf, true);
        g.setColour(kArcTrack);
        g.strokePath(track, juce::PathStrokeType(3.5f, juce::PathStrokeType::curved,
                                                  juce::PathStrokeType::rounded));
    }

    // Arc fill (proportional to value)
    if (norm > 0.005f)
    {
        juce::Path fill;
        fill.addCentredArc(cx, cy, arcR, arcR, 0.0f,
                           kStartAngle + piHalf, valAngle + piHalf, true);
        g.setColour(kArcFill);
        g.strokePath(fill, juce::PathStrokeType(3.5f, juce::PathStrokeType::curved,
                                                 juce::PathStrokeType::rounded));
    }

    // Knob body
    g.setColour(kKnobBody);
    g.fillEllipse(cx - innerR, cy - innerR, innerR * 2, innerR * 2);
    g.setColour(kKnobBorder);
    g.drawEllipse(cx - innerR, cy - innerR, innerR * 2, innerR * 2, 1.0f);

    // Pointer dot — position on the arc at the value angle
    // Convert our "clockwise from 12 o'clock" angle to standard trig:
    //   trig angle = -(our angle) + pi/2
    // Or equivalently: x = sin(angle), y = -cos(angle) for clockwise-from-top
    {
        const float dotR = innerR - 4.0f;
        const float dx = cx + dotR * std::sin(valAngle);
        const float dy = cy - dotR * std::cos(valAngle);
        g.setColour(kDot);
        g.fillEllipse(dx - 2.0f, dy - 2.0f, 4.0f, 4.0f);
    }

    // Label (below knob) — use FontOptions for JUCE 8 compatibility
    {
        g.setColour(kLabel);
        g.setFont(juce::FontOptions(9.0f));
        g.drawText(labelText, 0, (int)(cy + outerR + 2), (int)w, 12,
                   juce::Justification::centred);
    }

    // Value (below label)
    {
        g.setColour(kValue);
        g.setFont(juce::FontOptions(11.0f));
        g.drawText(juce::String((int)slider.getValue()),
                   0, (int)(cy + outerR + 14), (int)w, 12,
                   juce::Justification::centred);
    }
}

void JT8000Knob::mouseDown(const juce::MouseEvent& e)       { slider.mouseDown(e.getEventRelativeTo(&slider)); }
void JT8000Knob::mouseDrag(const juce::MouseEvent& e)       { slider.mouseDrag(e.getEventRelativeTo(&slider)); }
void JT8000Knob::mouseDoubleClick(const juce::MouseEvent& e) { slider.mouseDoubleClick(e.getEventRelativeTo(&slider)); }
void JT8000Knob::mouseWheelMove(const juce::MouseEvent& e, const juce::MouseWheelDetails& w)
{ slider.mouseWheelMove(e.getEventRelativeTo(&slider), w); }
