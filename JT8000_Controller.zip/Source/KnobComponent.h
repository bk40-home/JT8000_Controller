#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>

class JT8000Knob : public juce::Component,
                    private juce::Slider::Listener
{
public:
    JT8000Knob(const juce::String& label);
    void setAttachment(juce::AudioProcessorValueTreeState& apvts,
                       const juce::String& paramID);

    void paint(juce::Graphics& g) override;
    void resized() override;
    void mouseDown(const juce::MouseEvent& e) override;
    void mouseDrag(const juce::MouseEvent& e) override;
    void mouseDoubleClick(const juce::MouseEvent& e) override;
    void mouseWheelMove(const juce::MouseEvent&, const juce::MouseWheelDetails&) override;

private:
    void sliderValueChanged(juce::Slider*) override { repaint(); }

    juce::String labelText;
    juce::Slider slider;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachment;

    // JUCE arc angles: radians, clockwise from 12 o'clock
    // 7 o'clock = -2.356 rad (= -135 deg), 5 o'clock = +2.356 rad
    // Total sweep = 4.712 rad (= 270 deg)
    static constexpr float kStartAngle = -3.0f;   // 7 o'clock
    static constexpr float kEndAngle   =  3.0f;   // 5 o'clock

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(JT8000Knob)
};
