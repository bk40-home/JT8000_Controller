/*
 * CCDefinitions.h — JT-8000 CC Parameter Registry
 *
 * Single source of truth mirroring CCDefs.h from the Teensy firmware.
 */

#pragma once
#include <juce_core/juce_core.h>

// Section identifiers for UI grouping
enum class Section : int
{
    OSC1 = 0, OSC2, MIXER, FILTER,
    AMP_ENV, FILTER_ENV, PITCH_ENV,
    LFO1, LFO2,
    FX_EQ, FX_MOD, FX_MOD_TUNE, FX_DELAY, FX_REVERB, FX_OUTPUT,
    VELOCITY, PERFORMANCE, BPM,
    NUM_SECTIONS
};

static const char* sectionNames[] = {
    "Oscillator 1", "Oscillator 2", "Mixer", "Filter",
    "Amp Envelope", "Filter Envelope", "Pitch Envelope",
    "LFO 1", "LFO 2",
    "EQ & Drive", "Mod FX", "Mod Tuning", "Delay", "Reverb", "Output Mix",
    "Velocity", "Performance", "BPM Clock"
};

// Parameter definition
struct CCParam
{
    int         cc;
    const char* id;
    const char* name;
    Section     section;
    int         defVal;
    bool        isEnum;
    // For enum params: pointer to null-terminated array of option names, and count
    const char* const* enumNames;
    int                enumCount;
};

// ---------------------------------------------------------------------------
// Named option arrays for enum parameters
// ---------------------------------------------------------------------------
static const char* const kWaveNames[] = {
    "Sine","Sawtooth","Square","Triangle","Arbitrary","Pulse",
    "Saw Rev","S&H","Tri Var","BL Saw","BL Saw Rev","BL Square","BL Pulse","Supersaw"
};
static const char* const kLfoWaveNames[] = {
    "Sine","Sawtooth","Square","Triangle","Arbitrary","Pulse",
    "Saw Rev","S&H","Tri Var","BL Saw","BL Saw Rev","BL Square","BL Pulse"
};
static const char* const kLfoDestNames[] = { "None","Pitch","Filter","PWM","Amp" };
static const char* const kTimingNames[] = {
    "Free","1/16","1/8T","1/8","1/4T","1/4","1/2T","1/2","1 bar","2 bar","3 bar","4 bar"
};
static const char* const kModFxNames[] = {
    "Off","Chorus 1","Chorus 2","Chorus 3",
    "Flanger 1","Flanger 2","Deep Flanger",
    "Phaser 1","Phaser 2","Phaser 3","Phaser 4","Super Chorus"
};
static const char* const kDelayFxNames[] = {
    "Off","Mono Short","Mono Long","Pan L>R","Pan R>L","Pan Stereo"
};
static const char* const kDriveNames[] = { "Bypass","Soft Clip","Hard Clip" };
static const char* const kModTapNames[] = { "1 Tap","3 Tap (Ensemble)" };
static const char* const kModLfoNames[] = { "Triangle (BBD)","Sine (Smooth)" };
static const char* const kFltEngNames[] = { "OBXa","VA Bank" };
static const char* const kFltModeNames[] = {
    "4-Pole LP","2-Pole LP","2-Pole BP","2-Pole Push","Xpander","Xpander+M"
};
static const char* const kVaTypeNames[] = {
    "SVF LP2","SVF HP2","SVF BP2","SVF Notch","SVF AP",
    "Moog LP4","Moog LP2","Moog BP2","Diode LP4","Korg35 LP","Korg35 HP","TPT1 LP","TPT1 HP"
};
static const char* const kXpModeNames[] = {
    "LP4","LP3","LP2","LP1","HP3","HP2","HP1","BP4","BP2",
    "N2","PH3","HP2+LP1","HP3+LP1","N2+LP1","PH3+LP1"
};
static const char* const kClockNames[] = { "Internal","External" };
static const char* const kPolyNames[] = { "Poly","Mono","Unison" };
static const char* const kOnOffNames[] = { "Off","On" };
static const char* const kBypassNames[] = { "Active","Bypass" };
static const char* const kArbBankNames[] = { "BwBlended","BwPerfect","BwSaw","BwSawBright","BwSawGap","BwSawRound","BwSin","BwSqu","BwSquRound","BwTri" };

// Shorthand for non-enum params
#define NO_ENUM nullptr, 0

// Master parameter table
static const CCParam kAllParams[] =
{
    // === OSC 1 ===
    { 21,  "osc1_wave",      "OSC1 Wave",       Section::OSC1,     0,   true,  kWaveNames, 14 },
    { 41,  "osc1_pitch",     "OSC1 Pitch",      Section::OSC1,     65,  false, NO_ENUM },
    { 45,  "osc1_fine",      "OSC1 Fine",       Section::OSC1,     64,  false, NO_ENUM },
    { 43,  "osc1_detune",    "OSC1 Detune",     Section::OSC1,     65,  false, NO_ENUM },
    { 77,  "osc1_ss_det",    "SS1 Detune",      Section::OSC1,     0,   false, NO_ENUM },
    { 78,  "osc1_ss_mix",    "SS1 Mix",         Section::OSC1,     0,   false, NO_ENUM },
    { 123, "osc1_fb_amt",    "OSC1 FB Amt",     Section::OSC1,     0,   false, NO_ENUM },
    { 125, "osc1_fb_mix",    "OSC1 FB Mix",     Section::OSC1,     0,   false, NO_ENUM },
    { 86,  "osc1_freq_dc",   "OSC1 Freq DC",    Section::OSC1,     0,   false, NO_ENUM },
    { 87,  "osc1_shape_dc",  "OSC1 Shape DC",   Section::OSC1,     0,   false, NO_ENUM },
    { 91,  "osc1_ring",      "Ring 1",          Section::OSC1,     0,   false, NO_ENUM },
    { 101, "osc1_arb_bank",  "OSC1 Bank",       Section::OSC1,     0,   true,  kArbBankNames, 10 },
    { 83,  "osc1_arb_idx",   "OSC1 Table",      Section::OSC1,     0,   false, NO_ENUM },

    // === OSC 2 ===
    { 22,  "osc2_wave",      "OSC2 Wave",       Section::OSC2,     0,   true,  kWaveNames, 14 },
    { 42,  "osc2_pitch",     "OSC2 Pitch",      Section::OSC2,     65,  false, NO_ENUM },
    { 46,  "osc2_fine",      "OSC2 Fine",       Section::OSC2,     64,  false, NO_ENUM },
    { 44,  "osc2_detune",    "OSC2 Detune",     Section::OSC2,     65,  false, NO_ENUM },
    { 79,  "osc2_ss_det",    "SS2 Detune",      Section::OSC2,     0,   false, NO_ENUM },
    { 80,  "osc2_ss_mix",    "SS2 Mix",         Section::OSC2,     0,   false, NO_ENUM },
    { 124, "osc2_fb_amt",    "OSC2 FB Amt",     Section::OSC2,     0,   false, NO_ENUM },
    { 126, "osc2_fb_mix",    "OSC2 FB Mix",     Section::OSC2,     0,   false, NO_ENUM },
    { 88,  "osc2_freq_dc",   "OSC2 Freq DC",    Section::OSC2,     0,   false, NO_ENUM },
    { 89,  "osc2_shape_dc",  "OSC2 Shape DC",   Section::OSC2,     0,   false, NO_ENUM },
    { 92,  "osc2_ring",      "Ring 2",          Section::OSC2,     0,   false, NO_ENUM },
    { 102, "osc2_arb_bank",  "OSC2 Bank",       Section::OSC2,     0,   true,  kArbBankNames, 10 },
    { 85,  "osc2_arb_idx",   "OSC2 Table",      Section::OSC2,     0,   false, NO_ENUM },

    // === MIXER ===
    { 47,  "osc_bal",        "Osc Balance",     Section::MIXER,    0,   false, NO_ENUM },
    { 60,  "osc1_mix",       "OSC1 Level",      Section::MIXER,    127, false, NO_ENUM },
    { 61,  "osc2_mix",       "OSC2 Level",      Section::MIXER,    0,   false, NO_ENUM },
    { 58,  "sub_mix",        "Sub",             Section::MIXER,    0,   false, NO_ENUM },
    { 59,  "noise_mix",      "Noise",           Section::MIXER,    0,   false, NO_ENUM },

    // === FILTER ===
    { 23,  "flt_cut",        "Cutoff",          Section::FILTER,   127, false, NO_ENUM },
    { 24,  "flt_res",        "Resonance",       Section::FILTER,   0,   false, NO_ENUM },
    { 48,  "flt_env",        "Flt Env Amt",     Section::FILTER,   65,  false, NO_ENUM },
    { 50,  "flt_key",        "Key Track",       Section::FILTER,   65,  false, NO_ENUM },
    { 84,  "flt_oct",        "Oct Ctrl",        Section::FILTER,   0,   false, NO_ENUM },
    { 113, "flt_engine",     "Engine",          Section::FILTER,   0,   true,  kFltEngNames, 2 },
    { 112, "flt_mode",       "OBXa Mode",       Section::FILTER,   0,   true,  kFltModeNames, 6 },
    { 115, "va_type",        "VA Type",         Section::FILTER,   0,   true,  kVaTypeNames, 13 },
    { 111, "flt_multi",      "Multimode",       Section::FILTER,   0,   false, NO_ENUM },
    { 117, "flt_resmod",     "Res Mod",         Section::FILTER,   0,   false, NO_ENUM },
    { 114, "flt_xp",         "Xpander Mode",    Section::FILTER,   0,   true,  kXpModeNames, 15 },

    // === AMP ENV ===
    { 25,  "amp_a",  "Amp Atk",   Section::AMP_ENV,    0,   false, NO_ENUM },
    { 26,  "amp_d",  "Amp Dec",   Section::AMP_ENV,    0,   false, NO_ENUM },
    { 27,  "amp_s",  "Amp Sus",   Section::AMP_ENV,    127, false, NO_ENUM },
    { 28,  "amp_r",  "Amp Rel",   Section::AMP_ENV,    0,   false, NO_ENUM },

    // === FILTER ENV ===
    { 29,  "fe_a",   "Flt Atk",   Section::FILTER_ENV, 0,   false, NO_ENUM },
    { 30,  "fe_d",   "Flt Dec",   Section::FILTER_ENV, 0,   false, NO_ENUM },
    { 31,  "fe_s",   "Flt Sus",   Section::FILTER_ENV, 127, false, NO_ENUM },
    { 32,  "fe_r",   "Flt Rel",   Section::FILTER_ENV, 0,   false, NO_ENUM },

    // === PITCH ENV ===
    { 65,  "pe_a",     "Pitch Atk",   Section::PITCH_ENV, 0,   false, NO_ENUM },
    { 66,  "pe_d",     "Pitch Dec",   Section::PITCH_ENV, 0,   false, NO_ENUM },
    { 67,  "pe_s",     "Pitch Sus",   Section::PITCH_ENV, 0,   false, NO_ENUM },
    { 68,  "pe_r",     "Pitch Rel",   Section::PITCH_ENV, 0,   false, NO_ENUM },
    { 69,  "pe_depth", "Pitch Depth", Section::PITCH_ENV, 64,  false, NO_ENUM },

    // === LFO 1 ===
    { 62,  "l1_wave",  "LFO1 Wave",    Section::LFO1, 0,  true,  kLfoWaveNames, 13 },
    { 54,  "l1_freq",  "LFO1 Rate",    Section::LFO1, 0,  false, NO_ENUM },
    { 55,  "l1_depth", "LFO1 Depth",   Section::LFO1, 0,  false, NO_ENUM },
    { 56,  "l1_dest",  "LFO1 Dest",    Section::LFO1, 0,  true,  kLfoDestNames, 5 },
    { 120, "l1_sync",  "LFO1 Sync",    Section::LFO1, 0,  true,  kTimingNames, 12 },
    { 33,  "l1_p_dep", "L1 Pitch",     Section::LFO1, 0,  false, NO_ENUM },
    { 34,  "l1_f_dep", "L1 Filter",    Section::LFO1, 0,  false, NO_ENUM },
    { 35,  "l1_w_dep", "L1 PWM",       Section::LFO1, 0,  false, NO_ENUM },
    { 36,  "l1_a_dep", "L1 Amp",       Section::LFO1, 0,  false, NO_ENUM },
    { 37,  "l1_delay", "L1 Delay",     Section::LFO1, 0,  false, NO_ENUM },

    // === LFO 2 ===
    { 63,  "l2_wave",  "LFO2 Wave",    Section::LFO2, 0,  true,  kLfoWaveNames, 13 },
    { 51,  "l2_freq",  "LFO2 Rate",    Section::LFO2, 0,  false, NO_ENUM },
    { 52,  "l2_depth", "LFO2 Depth",   Section::LFO2, 0,  false, NO_ENUM },
    { 53,  "l2_dest",  "LFO2 Dest",    Section::LFO2, 0,  true,  kLfoDestNames, 5 },
    { 121, "l2_sync",  "LFO2 Sync",    Section::LFO2, 0,  true,  kTimingNames, 12 },
    { 38,  "l2_p_dep", "L2 Pitch",     Section::LFO2, 0,  false, NO_ENUM },
    { 39,  "l2_f_dep", "L2 Filter",    Section::LFO2, 0,  false, NO_ENUM },
    { 40,  "l2_w_dep", "L2 PWM",       Section::LFO2, 0,  false, NO_ENUM },
    { 57,  "l2_a_dep", "L2 Amp",       Section::LFO2, 0,  false, NO_ENUM },
    { 64,  "l2_delay", "L2 Delay",     Section::LFO2, 0,  false, NO_ENUM },

    // === FX EQ ===
    { 99,  "fx_bass",   "Bass",    Section::FX_EQ, 64, false, NO_ENUM },
    { 100, "fx_treble", "Treble",  Section::FX_EQ, 64, false, NO_ENUM },
    { 16, "fx_drive",  "Drive",   Section::FX_EQ, 0,  true,  kDriveNames, 3 },

    // === FX MOD ===
    { 103, "fx_mod_type", "Mod Type",  Section::FX_MOD, 0, true,  kModFxNames, 12 },
    { 104, "fx_mod_mix",  "Mod Mix",   Section::FX_MOD, 0, false, NO_ENUM },
    { 105, "fx_mod_rate", "Mod Rate",  Section::FX_MOD, 0, false, NO_ENUM },
    { 106, "fx_mod_fb",   "Mod FB",    Section::FX_MOD, 0, false, NO_ENUM },

    // === FX MOD TUNE ===
    { 95,  "fx_mod_depth", "Mod Depth",     Section::FX_MOD_TUNE, 4,  false, NO_ENUM },
    { 96,  "fx_mod_base",  "Mod Base Dly",  Section::FX_MOD_TUNE, 13, false, NO_ENUM },
    { 97,  "fx_mod_taps",  "Mod Taps",      Section::FX_MOD_TUNE, 0,  true,  kModTapNames, 2 },
    { 98,  "fx_mod_lfo",   "Mod LFO",       Section::FX_MOD_TUNE, 0,  true,  kModLfoNames, 2 },

    // === FX DELAY ===
    { 107, "fx_dly_type", "Delay Type",  Section::FX_DELAY, 0, true,  kDelayFxNames, 6 },
    { 110, "fx_dly_time", "Delay Time",  Section::FX_DELAY, 0, false, NO_ENUM },
    { 108, "fx_dly_mix",  "Delay Mix",   Section::FX_DELAY, 0, false, NO_ENUM },
    { 109, "fx_dly_fb",   "Delay FB",    Section::FX_DELAY, 0, false, NO_ENUM },

    // === FX REVERB ===
    { 70,  "fx_rv_size",   "Rev Size",    Section::FX_REVERB, 0, false, NO_ENUM },
    { 71,  "fx_rv_damp",   "Rev HiDamp",  Section::FX_REVERB, 0, false, NO_ENUM },
    { 93,  "fx_rv_lodamp", "Rev LoDamp",  Section::FX_REVERB, 0, false, NO_ENUM },
    { 75,  "fx_rv_mix",    "Rev Mix",     Section::FX_REVERB, 0, false, NO_ENUM },
    { 94,  "fx_rv_bypass", "Rev Bypass",  Section::FX_REVERB, 0, true,  kBypassNames, 2 },

    // === FX OUTPUT ===
    { 74,  "fx_dry",  "Dry Mix",  Section::FX_OUTPUT, 127, false, NO_ENUM },
    { 76,  "fx_jpfx", "JPFX Mix", Section::FX_OUTPUT, 127, false, NO_ENUM },

    // === VELOCITY ===
    { 10,  "vel_amp", "Vel Amp",    Section::VELOCITY, 0, false, NO_ENUM },
    { 11,  "vel_flt", "Vel Filter", Section::VELOCITY, 0, false, NO_ENUM },
    { 12,  "vel_env", "Vel Env",    Section::VELOCITY, 0, false, NO_ENUM },

    // === PERFORMANCE ===
    { 81,  "glide_on",   "Glide",        Section::PERFORMANCE, 0,   true,  kOnOffNames, 2 },
    { 82,  "glide_time", "Glide Time",   Section::PERFORMANCE, 0,   false, NO_ENUM },
    { 127, "bend_range", "Bend Range",   Section::PERFORMANCE, 12,  false, NO_ENUM },
    { 90,  "amp_level",  "Amp Level",    Section::PERFORMANCE, 127, false, NO_ENUM },
    { 14, "poly_mode",  "Voice Mode",   Section::PERFORMANCE, 21,  true,  kPolyNames, 3 },
    { 15, "uni_det",    "Unison Det",   Section::PERFORMANCE, 0,   false, NO_ENUM },

    // === BPM ===
    { 118, "bpm_src",   "Clock",      Section::BPM, 0, true,  kClockNames, 2 },
    { 119, "bpm_tempo", "Int BPM",    Section::BPM, 0, false, NO_ENUM },
    { 122, "dly_sync",  "Delay Sync", Section::BPM, 0, true,  kTimingNames, 12 },
};

static constexpr int kNumParams = sizeof(kAllParams) / sizeof(kAllParams[0]);

inline const CCParam* findParamByCC(int cc)
{
    for (int i = 0; i < kNumParams; ++i)
        if (kAllParams[i].cc == cc) return &kAllParams[i];
    return nullptr;
}

inline const CCParam* findParamByID(const juce::String& id)
{
    for (int i = 0; i < kNumParams; ++i)
        if (id == kAllParams[i].id) return &kAllParams[i];
    return nullptr;
}
