# JT-8000 Controller — Architecture & Layout Guide

## Project Structure

```
JT8000_Controller/
  CMakeLists.txt              ← Build config (rarely needs changing)
  Source/
    CCDefinitions.h           ← THE MASTER FILE — all CCs, names, sections
    PluginProcessor.h/.cpp    ← Audio/MIDI engine (zero DSP, CC queue)
    PluginEditor.h/.cpp       ← Main window, header bar, viewport
    SectionComponent.h/.cpp   ← Collapsible section panel
    KnobComponent.h/.cpp      ← Custom rotary knob drawing
```

## How it all connects

```
CCDefinitions.h (data)
       │
       ▼
PluginProcessor (creates JUCE parameters from kAllParams[])
       │
       ▼
PluginEditor (reads kAllParams[], creates SectionComponents)
       │
       ▼
SectionComponent (holds knobs/combos/toggles, draws header)
       │
       ▼
KnobComponent (draws the orange arc knob, wraps a hidden Slider)
```

**The key insight**: Everything is driven by the `kAllParams[]` table in
`CCDefinitions.h`.  Adding/removing/reordering a CC means changing ONE line
in that table.  The processor, editor, and sections all read from it
automatically.

---

## File-by-file guide

### CCDefinitions.h — The single source of truth

This is the file you'll edit most often.  It contains:

**1. Section enum** — defines which collapsible panels exist:
```cpp
enum class Section : int
{
    OSC1 = 0, OSC2, MIXER, FILTER,
    // ...add new sections here...
    NUM_SECTIONS   // must be last
};
```

**2. Section names** — displayed in the panel headers:
```cpp
static const char* sectionNames[] = {
    "Oscillator 1", "Oscillator 2", "Mixer", "Filter",
    // ...must match Section enum order exactly...
};
```

**3. Named option arrays** — for dropdown menus:
```cpp
static const char* const kWaveNames[] = {
    "Sine","Sawtooth","Square", ...
};
```

**4. The parameter table** — one entry per CC:
```cpp
static const CCParam kAllParams[] =
{
    //  CC   ID             Name           Section         Default  IsEnum  EnumNames      EnumCount
    { 21,  "osc1_wave",    "OSC1 Wave",   Section::OSC1,  0,       true,   kWaveNames,    14 },
    { 41,  "osc1_pitch",   "OSC1 Pitch",  Section::OSC1,  65,      false,  NO_ENUM },
    // ...
};
```

Each field:
- `cc` — MIDI CC number (must match CCDefs.h on the Teensy)
- `id` — unique string, used by JUCE internally (no spaces, no duplicates)
- `name` — what the user sees on the knob label and in DAW automation
- `section` — which collapsible panel this control appears in
- `defVal` — default value (0-127) on init/reset
- `isEnum` — `true` = shows as dropdown, `false` = shows as knob
- `enumNames` — pointer to a `const char*[]` array (or `nullptr` via `NO_ENUM`)
- `enumCount` — number of items in the enum array

### Common tasks in CCDefinitions.h:

**Add a new CC parameter:**
```cpp
// Just add a line to kAllParams[]:
{ 95, "fx_mod_depth", "Mod Depth", Section::FX_MOD_TUNE, 4, false, NO_ENUM },
```

**Add a new enum parameter with named options:**
```cpp
// 1. Define the names array:
static const char* const kMyNames[] = { "Option A", "Option B", "Option C" };

// 2. Add the parameter entry:
{ 99, "my_param", "My Param", Section::FILTER, 0, true, kMyNames, 3 },
```

**Add a new section:**
```cpp
// 1. Add to the enum (before NUM_SECTIONS):
enum class Section : int {
    // ...existing...
    MY_NEW_SECTION,
    NUM_SECTIONS
};

// 2. Add the name (same position in the array):
static const char* sectionNames[] = {
    // ...existing...
    "My New Section",
};

// 3. Add parameters that reference it:
{ 42, "my_cc", "My CC", Section::MY_NEW_SECTION, 0, false, NO_ENUM },
```

**Move a parameter to a different section:**
Just change the `Section::XXX` value in its table entry.

**Reorder parameters within a section:**
Reorder the lines in `kAllParams[]`.  Parameters appear in the section
in the order they're listed in the table.

---

### PluginProcessor.h/.cpp — The MIDI engine

**What it does:**
- Creates one JUCE `AudioParameterInt` (0-127) per entry in `kAllParams[]`
- Listens for parameter changes (from UI knobs OR DAW automation)
- Sends MIDI CC via two paths:
  - `directMidiOut` — immediate `sendMessageNow()` for standalone mode
  - FIFO queue → `processBlock()` `MidiBuffer` for DAW mode
- Saves/restores all parameter values as XML (DAW session recall)

**You rarely need to edit this file.** It's fully data-driven from
`kAllParams[]`.  The only reasons to touch it:

- Change the MIDI sending behaviour
- Add features like MIDI learn or preset banks
- Change the audio bus layout (currently stereo passthrough)

**Key functions:**
```cpp
createParameterLayout()  // Builds JUCE parameters from kAllParams[]
parameterChanged()       // APVTS callback → sendCC()
sendCC()                 // Sends via direct output AND queues for processBlock
sendAllCCs()             // Dumps all current values (called by "Send All" button)
setMidiOutput()          // Called by editor when user picks a MIDI device
```

---

### PluginEditor.h/.cpp — The main window

**What it does:**
- Creates the header bar (title, MIDI output picker, channel, buttons)
- Creates one `SectionComponent` per `Section` enum value
- Populates each section with knobs/combos from `kAllParams[]`
- Manages the scrollable viewport and section layout

**Layout structure:**
```
┌─────────────────────────────────────────────┐
│  HEADER BAR (kHeaderHeight = 44px)          │
│  [Title] [MIDI Out ▼] [Ch ▼] [Send] [±]    │
├─────────────────────────────────────────────┤
│  VIEWPORT (scrollable)                      │
│  ┌─────────────────────────────────────┐    │
│  │ Section: Oscillator 1  [▼]          │    │
│  │  [Knob] [Knob] [Combo] [Knob] ...  │    │
│  ├─────────────────────────────────────┤    │
│  │ Section: Oscillator 2  [▼]          │    │
│  │  [Knob] [Knob] [Combo] [Knob] ...  │    │
│  ├─────────────────────────────────────┤    │
│  │ ... more sections ...               │    │
│  └─────────────────────────────────────┘    │
└─────────────────────────────────────────────┘
```

**Key functions you might edit:**

```cpp
buildSections()     // Creates sections, populates with controls
layoutSections()    // Stacks sections vertically, sizes the content panel
resized()           // Positions header controls and viewport
```

**To change the header layout**, edit `resized()`:
```cpp
void JT8000ControllerEditor::resized()
{
    auto area = getLocalBounds();
    auto hdr = area.removeFromTop(kHeaderHeight).reduced(6, 6);

    // These are laid out right-to-left from the right edge:
    titleLabel.setBounds(hdr.removeFromLeft(90));
    collapseBtn.setBounds(hdr.removeFromRight(66));
    expandBtn.setBounds(hdr.removeFromRight(60));
    sendAllBtn.setBounds(hdr.removeFromRight(66));
    midiChSelector.setBounds(hdr.removeFromRight(60));
    midiOutSelector.setBounds(hdr.removeFromRight(juce::jmin(180, hdr.getWidth())));

    viewport.setBounds(area);  // everything below the header
    layoutSections();
}
```

**To change the window size**, edit the constructor:
```cpp
setSize(680, 820);                          // initial size
setResizeLimits(400, 400, 1400, 2400);      // min/max
```

**To change section colours**, edit `sectionLed()`:
```cpp
static juce::Colour sectionLed(Section s)
{
    switch (s) {
        case Section::OSC1:  return juce::Colour(0xfff08020u);  // orange
        case Section::FILTER: return juce::Colour(0xff40a0ffu); // blue
        // ...
    }
}
```

---

### SectionComponent.h/.cpp — Collapsible panel

**What it does:**
- Draws a dark rounded rectangle with a coloured header
- Click header → toggle open/closed
- Contains knobs, combo boxes, and toggles in a flow layout
- Reports its desired height (header-only when collapsed, full when open)
- Fires `onLayoutChanged` callback so the editor can relayout

**Layout inside a section** — flow layout (left to right, wraps to next row):
```
┌──────────────────────────────────────────┐
│ ● Section Title                        ▼ │  ← header (32px)
├──────────────────────────────────────────┤
│ [Knob] [Knob] [Combo] [Knob] [Combo]    │  ← row 1 (76px)
│ [Knob] [Knob] [Toggle]                  │  ← row 2 (wraps)
└──────────────────────────────────────────┘
```

**To change control sizes**, edit the `addKnob` / `addComboBox` / `addToggle`
methods — each pushes a `preferredWidth` and `preferredHeight`:
```cpp
void SectionComponent::addKnob(...) {
    // ...
    _controls.push_back({ knob, 58, 72 });  // width=58, height=72
}

void SectionComponent::addComboBox(...) {
    // ...
    _controls.push_back({ combo, 120, 40 }); // width=120, height=40
}
```

**To change the flow layout**, edit `resized()`:
```cpp
void SectionComponent::resized()
{
    const int startY = kHeaderHeight + 10;  // gap below header
    const int pad    = 12;                  // left/right margin
    const int rowH   = 76;                  // height per row
    const int availW = getWidth() - 2 * pad;
    int x = pad, y = startY;

    for (auto& c : _controls)
    {
        if (x + c.preferredWidth > pad + availW && x > pad)
        {
            x = pad;       // wrap to next row
            y += rowH;
        }
        c.comp->setBounds(x, y, c.preferredWidth, c.preferredHeight);
        x += c.preferredWidth + 6;  // gap between controls
    }
}
```

**To change the section header height:**
```cpp
static constexpr int kHeaderHeight = 32;  // change this
```

---

### KnobComponent.h/.cpp — The rotary knob

**What it does:**
- Wraps a hidden `juce::Slider` (handles mouse drag, automation, value)
- Draws a custom arc knob on top using `juce::Graphics`
- Shows a label below and the raw value below that

**Knob anatomy:**
```
        ╭──── arc track (dark, 270°)
       ╱
    ┌─╱──────╮
    │ ╭────╮ │ ← arc fill (orange, proportional to value)
    │ │ ·  │ │ ← pointer dot (white, follows value angle)
    │ ╰────╯ │ ← knob body (dark circle)
    └────────┘
      LABEL       ← param name (grey)
       64         ← current value (orange)
```

**To change knob size**, edit the paint calculations:
```cpp
const float knobDiam = juce::jmin(w, h - 26.0f);  // 26px reserved for text
const float outerR = knobDiam * 0.42f;              // arc radius
const float innerR = knobDiam * 0.30f;              // body radius
```

**To change colours**, edit the constants at the top of KnobComponent.cpp:
```cpp
static const juce::Colour kArcFill   (0xfff08020);  // orange arc
static const juce::Colour kArcTrack  (0xff0a1018);  // dark track
static const juce::Colour kDot       (0xffc0c8e0);  // pointer dot
static const juce::Colour kLabel     (0xff8090b0);  // label text
static const juce::Colour kValue     (0xffffa040);  // value text
```

**JUCE arc angle convention** (this tripped us up):
- 0 radians = 12 o'clock (top)
- Positive = clockwise
- 7 o'clock = -2.356 rad (-135°)
- 5 o'clock = +2.356 rad (+135°)
- Total sweep = 4.712 rad (270°)

For the pointer dot position, convert to standard trig:
```cpp
float dx = cx + radius * std::sin(angle);   // X: sin for clockwise-from-top
float dy = cy - radius * std::cos(angle);   // Y: -cos for clockwise-from-top
```

---

## Common recipes

### Add a brand new CC to the synth

1. Add it to `CCDefs.h` on the Teensy:
   ```cpp
   static constexpr uint8_t MY_NEW_PARAM = 95;
   ```

2. Add it to `CCDefinitions.h` in the plugin:
   ```cpp
   { 95, "my_new_param", "My New Param", Section::FX_MOD, 0, false, NO_ENUM },
   ```

3. Rebuild.  Done.  The parameter appears in the correct section automatically.

### Split a section into two

1. Add a new `Section` enum value
2. Add its name to `sectionNames[]`
3. Change the `Section::XXX` field on the parameters you want to move
4. Optionally add a colour in `sectionLed()` in PluginEditor.cpp

### Change the order sections appear on screen

Sections appear in the order of the `Section` enum.  Reorder the enum
values (and keep `sectionNames[]` in sync).

### Make a parameter show as a toggle instead of a knob

In `CCDefinitions.h`, set `isEnum = true` and use `kOnOffNames`:
```cpp
{ 81, "glide_on", "Glide", Section::PERFORMANCE, 0, true, kOnOffNames, 2 },
```

Note: JUCE's APVTS `ComboBoxAttachment` maps combo index 1..N to parameter
values distributed across 0..127.  For a 2-item list, index 1 maps to ~0
and index 2 maps to ~127.  This matches the Teensy's `cc >= 64` boolean
convention.

### Change the MIDI channel range or default

In `PluginProcessor.h`:
```cpp
std::atomic<int> midiChannel { 1 };  // change default here
```

### Add a "Refresh MIDI" button

In `PluginEditor.cpp`, add a button that calls `refreshMidiOutputList()`:
```cpp
refreshBtn.onClick = [this] { refreshMidiOutputList(); };
```

---

## JUCE colour gotcha (your version)

Your JUCE version requires explicit `Colour` construction.  Always write:
```cpp
return juce::Colour(0xfff08020u);     // OK
```
Never write:
```cpp
return {0xfff08020};                   // FAILS — explicit constructor
```

The `u` suffix (`0xfff08020u`) makes it an unsigned literal, which avoids
sign-conversion warnings on some compilers.

## JUCE Font gotcha (your version)

Your JUCE version deprecates `Font("name", size, style)`.  Use:
```cpp
g.setFont(juce::FontOptions(12.0f));                    // default font at 12pt
g.setFont(juce::FontOptions(12.0f, juce::Font::bold));  // bold
```

## Build commands (quick reference)

```cmd
:: First time / after CMakeLists.txt changes:
rmdir /s /q build
mkdir build && cd build
cmake .. -DJUCE_DIR=C:\path\to\JUCE
cmake --build . --config Release

:: After source file changes only:
cd build
cmake --build . --config Release
```

Output locations:
```
build\JT8000_Controller_artefacts\Release\VST3\      ← .vst3 for Ableton
build\JT8000_Controller_artefacts\Release\Standalone\ ← .exe for testing
```
