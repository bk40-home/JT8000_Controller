/*
 * PluginEditor.cpp — JT-8000 Controller Main Window
 */

#include "PluginEditor.h"

static const juce::Colour kBg       (0xff0b0e14);
static const juce::Colour kHeaderBg (0xff141a28);
static const juce::Colour kBorder   (0xff1e2a3e);
static const juce::Colour kOrange   (0xfff08020);
static const juce::Colour kTextHi   (0xffc8d8f4);
static const juce::Colour kText     (0xff8090b0);



JT8000ControllerEditor::JT8000ControllerEditor(JT8000ControllerProcessor& p)
    : AudioProcessorEditor(p), _proc(p)
{
    setLookAndFeel(&_lnf);

    _titleLabel.setText("JT-8000", juce::dontSendNotification);
    _titleLabel.setColour(juce::Label::textColourId, kOrange);
    _titleLabel.setFont(juce::FontOptions(18.0f, juce::Font::bold));
    addAndMakeVisible(_titleLabel);

    for (int i = 1; i <= 16; ++i)
        _midiChSelector.addItem("Ch " + juce::String(i), i);
    _midiChSelector.setSelectedId(_proc.midiChannel.load());
    _midiChSelector.onChange = [this] { _proc.midiChannel.store(_midiChSelector.getSelectedId()); };
    addAndMakeVisible(_midiChSelector);

    _midiOutSelector.onChange = [this] {
        const int sel = _midiOutSelector.getSelectedId();
        if (sel <= 0) { _proc.setMidiOutput(nullptr); return; }
        auto devices = juce::MidiOutput::getAvailableDevices();
        const int idx = sel - 1;
        if (idx >= 0 && idx < devices.size())
            _proc.setMidiOutput(juce::MidiOutput::openDevice(devices[idx].identifier));
    };
    addAndMakeVisible(_midiOutSelector);
    refreshMidiOutputList();

    auto styleBtn = [](juce::TextButton& b, juce::Colour c) {
        b.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff161c28));
        b.setColour(juce::TextButton::textColourOffId, c);
    };

    styleBtn(_sendAllBtn, kOrange);
    _sendAllBtn.onClick = [this] {
        _proc.sendAllCCs();
        // Also send all step sequencer grid values
        for (auto* sec : _sections)
            for (auto* grid : sec->getStepGrids())
                grid->sendAllSteps();
    };

    _loadSyxBtn.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff161c28));
    _loadSyxBtn.setColour(juce::TextButton::textColourOffId, juce::Colour(0xff9040ff));
    _loadSyxBtn.onClick = [this] { loadSyxFile(); };

    styleBtn(_savePatchBtn, juce::Colour(0xff28ff58));
    styleBtn(_loadPatchBtn, juce::Colour(0xff28ff58));
    _savePatchBtn.onClick = [this] { savePatchFile(); };
    _loadPatchBtn.onClick = [this] { loadPatchFile(); };

    styleBtn(_expandBtn, kText);
    styleBtn(_collapseBtn, kText);
    _expandBtn.onClick   = [this] { for (auto* s : _sections) s->setOpen(true); };
    _collapseBtn.onClick = [this] { for (auto* s : _sections) s->setOpen(false); };

    for (auto* b : { &_sendAllBtn, &_loadSyxBtn, &_savePatchBtn, &_loadPatchBtn, &_expandBtn, &_collapseBtn })
        addAndMakeVisible(b);

    _viewport.setViewedComponent(&_contentPanel, false);
    _viewport.setScrollBarsShown(true, false);
    _viewport.getVerticalScrollBar().setColour(juce::ScrollBar::thumbColourId, juce::Colour(0xff283850));
    addAndMakeVisible(_viewport);

    buildSections();
    setSize(1080, 820);
    setResizable(true, true);
    setResizeLimits(400, 400, 1600, 2400);
}

void JT8000ControllerEditor::refreshMidiOutputList()
{
    _midiOutSelector.clear(juce::dontSendNotification);
    _midiOutSelector.addItem(juce::String::fromUTF8("\xe2\x80\x94 No MIDI Output \xe2\x80\x94"), -1);
    auto devices = juce::MidiOutput::getAvailableDevices();
    for (int i = 0; i < devices.size(); ++i)
        _midiOutSelector.addItem(devices[i].name, i + 1);
    _midiOutSelector.setSelectedId(-1, juce::dontSendNotification);
}

void JT8000ControllerEditor::buildSections()
{
    for (int s = 0; s < static_cast<int>(Section::NUM_SECTIONS); ++s)
    {
        auto* sec = _sections.add(
            new SectionComponent(sectionNames[s], juce::Colour(0xfff08020u), _lnf));
        sec->onLayoutChanged = [this] { layoutSections(); };
        _contentPanel.addAndMakeVisible(sec);
    }

    for (int i = 0; i < kNumParams; ++i)
    {
        const auto& p = kAllParams[i];
        auto* sec = _sections[static_cast<int>(p.section)];
        switch (p.style)
        {
            case ControlStyle::Knob:   sec->addKnob(_proc.apvts, p);     break;
            case ControlStyle::Slider: sec->addSlider(_proc.apvts, p);   break;
            case ControlStyle::Combo:  sec->addComboBox(_proc.apvts, p); break;
            case ControlStyle::Toggle: sec->addToggle(_proc.apvts, p);   break;
            case ControlStyle::StepGrid:
                sec->addStepGrid([this](int step, int value) {
                    _proc.sendCC(17, step);    // SEQ_STEP_SELECT
                    _proc.sendCC(18, value);   // SEQ_STEP_VALUE
                });
                break;
        }
    }
}

void JT8000ControllerEditor::layoutSections()
{
    const int scrollBarW = _viewport.getScrollBarThickness();
    const int totalW = _viewport.getWidth() - scrollBarW - 8;
    const int gap = 4;
    if (totalW <= 0) return;

    int y = gap, idx = 0;
    const int n = _sections.size();

    while (idx < n)
    {
        const int row = sectionRow[idx];
        if (row < 0)
        {
            auto* sec = _sections[idx];
            int h = sec->getDesiredHeight(totalW);
            sec->setBounds(gap, y, totalW, h);
            y += h + gap;
            ++idx;
        }
        else
        {
            int gs = idx;
            while (idx < n && sectionRow[idx] == row) ++idx;
            int gc = idx - gs;
            int sw = (totalW - (gc - 1) * gap) / gc;
            int maxH = 0;
            for (int g = 0; g < gc; ++g)
                maxH = juce::jmax(maxH, _sections[gs + g]->getDesiredHeight(sw));
            int xp = gap;
            for (int g = 0; g < gc; ++g)
            {
                _sections[gs + g]->setBounds(xp, y, sw, maxH);
                xp += sw + gap;
            }
            y += maxH + gap;
        }
    }
    _contentPanel.setSize(totalW + 2 * gap, y + gap);
}

void JT8000ControllerEditor::paint(juce::Graphics& g)
{
    g.fillAll(kBg);
    g.setColour(kHeaderBg);
    g.fillRect(0, 0, getWidth(), kHeaderHeight);
    g.setColour(kBorder);
    g.drawHorizontalLine(kHeaderHeight - 1, 0.0f, static_cast<float>(getWidth()));
}

void JT8000ControllerEditor::resized()
{
    auto area = getLocalBounds();
    auto hdr = area.removeFromTop(kHeaderHeight).reduced(6, 6);
    _titleLabel.setBounds(hdr.removeFromLeft(90));
    _collapseBtn.setBounds(hdr.removeFromRight(66));
    _expandBtn.setBounds(hdr.removeFromRight(60));
    _loadSyxBtn.setBounds(hdr.removeFromRight(72));
    _sendAllBtn.setBounds(hdr.removeFromRight(66));
    _loadPatchBtn.setBounds(hdr.removeFromRight(50));
    _savePatchBtn.setBounds(hdr.removeFromRight(50));
    _midiChSelector.setBounds(hdr.removeFromRight(60));
    _midiOutSelector.setBounds(hdr.removeFromRight(juce::jmin(180, hdr.getWidth())));
    _viewport.setBounds(area);
    layoutSections();
}

// --- SYX import ---
void JT8000ControllerEditor::loadSyxFile()
{
    _fileChooser = std::make_unique<juce::FileChooser>(
        "Load JP-8000 SysEx", juce::File::getSpecialLocation(juce::File::userDesktopDirectory),
        "*.syx;*.mid;*.SYX;*.MID");
    _fileChooser->launchAsync(
        juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
        [this](const juce::FileChooser& fc) {
            auto results = fc.getResults();
            if (results.isEmpty()) return;
            auto file = results.getFirst();
            juce::MemoryBlock mb;
            if (!file.loadFileAsData(mb) || mb.getSize() == 0) return;
            _syxBuffer = std::move(mb);
            _syxPatches = JP8000SyxImporter::parseFile(
                static_cast<const uint8_t*>(_syxBuffer.getData()), _syxBuffer.getSize(),
                file.getFileExtension().toLowerCase() == ".mid");
            if (_syxPatches.empty()) {
                juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::WarningIcon,
                    "No Patches Found", "No JP-8000 patches found in " + file.getFileName());
                return;
            }
            showPatchPicker(file.getFileName());
        });
}

void JT8000ControllerEditor::showPatchPicker(const juce::String& fileName)
{
    auto* dlg = new juce::AlertWindow(
        "Load SysEx \xe2\x80\x94 " + juce::String(static_cast<int>(_syxPatches.size())) + " patches",
        fileName, juce::MessageBoxIconType::NoIcon);
    juce::StringArray items;
    for (int i = 0; i < static_cast<int>(_syxPatches.size()); ++i)
        items.add(juce::String(i).paddedLeft('0', 2) + "  " + _syxPatches[static_cast<size_t>(i)].name);
    dlg->addComboBox("patchList", items, "Select patch:");
    dlg->addButton("Load + Send", 1);
    dlg->addButton("Load Only", 2);
    dlg->addButton("Cancel", 0);
    dlg->setColour(juce::AlertWindow::backgroundColourId, juce::Colour(0xff111620));
    dlg->setColour(juce::AlertWindow::textColourId, juce::Colour(0xffc8d8f4));
    dlg->setColour(juce::AlertWindow::outlineColourId, juce::Colour(0xff1e2a3e));

    juce::AlertWindow* dlgPtr = dlg;
    dlg->enterModalState(true, juce::ModalCallbackFunction::create(
        [this, dlgPtr](int result) {
            if (result == 0 || _syxPatches.empty()) return;
            auto* combo = dlgPtr->getComboBoxComponent("patchList");
            int idx = combo ? combo->getSelectedItemIndex() : 0;
            if (idx >= 0 && idx < static_cast<int>(_syxPatches.size())) {
                JP8000SyxImporter::loadPatch(_proc.apvts, _syxPatches[static_cast<size_t>(idx)]);
                if (result == 1) _proc.sendAllCCs();
            }
        }), true);
}

// --- Patch save/load ---
void JT8000ControllerEditor::savePatchFile()
{
    _fileChooser = std::make_unique<juce::FileChooser>(
        "Save JT-8000 Patch", juce::File::getSpecialLocation(juce::File::userDesktopDirectory), "*.jt8k");
    _fileChooser->launchAsync(
        juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles,
        [this](const juce::FileChooser& fc) {
            auto results = fc.getResults();
            if (results.isEmpty()) return;
            auto file = results.getFirst();
            if (!file.hasFileExtension("jt8k")) file = file.withFileExtension("jt8k");
            auto xml = _proc.apvts.copyState().createXml();
            if (xml && !xml->writeTo(file))
                juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::WarningIcon,
                    "Save Failed", "Could not write to " + file.getFileName());
        });
}

void JT8000ControllerEditor::loadPatchFile()
{
    _fileChooser = std::make_unique<juce::FileChooser>(
        "Load JT-8000 Patch", juce::File::getSpecialLocation(juce::File::userDesktopDirectory), "*.jt8k");
    _fileChooser->launchAsync(
        juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
        [this](const juce::FileChooser& fc) {
            auto results = fc.getResults();
            if (results.isEmpty()) return;
            auto file = results.getFirst();
            auto xml = juce::XmlDocument::parse(file);
            if (!xml) {
                juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::WarningIcon,
                    "Load Failed", "Could not parse " + file.getFileName());
                return;
            }
            if (!xml->hasTagName(_proc.apvts.state.getType())) {
                juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::WarningIcon,
                    "Invalid File", file.getFileName() + " is not a valid JT-8000 patch.");
                return;
            }
            _proc.apvts.replaceState(juce::ValueTree::fromXml(*xml));
            _proc.sendAllCCs();
        });
}
