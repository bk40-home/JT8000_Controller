/*
 * PluginProcessor.cpp — JT-8000 Controller Processor
 *
 * Key change: mixed parameter types.
 *   - Knob/Slider → AudioParameterInt(0, 127), CC = raw value
 *   - Combo/Toggle → AudioParameterChoice(names), CC = choiceIndexToCC(index, N)
 *
 * parameterChanged() detects the parameter type via findParamByID() and
 * applies the appropriate conversion before queuing the CC message.
 */

#include "PluginProcessor.h"
#include "PluginEditor.h"

// -----------------------------------------------------------------------
// Constructor / Destructor — register parameter listeners
// -----------------------------------------------------------------------
JT8000ControllerProcessor::JT8000ControllerProcessor()
    : AudioProcessor(BusesProperties()
          .withInput ("Input",  juce::AudioChannelSet::stereo(), true)
          .withOutput("Output", juce::AudioChannelSet::stereo(), true))
    , apvts(*this, nullptr, "JT8000State", createParameterLayout())
{
    for (int i = 0; i < kNumParams; ++i)
        apvts.addParameterListener(kAllParams[i].id, this);
}

JT8000ControllerProcessor::~JT8000ControllerProcessor()
{
    for (int i = 0; i < kNumParams; ++i)
        apvts.removeParameterListener(kAllParams[i].id, this);
}

// -----------------------------------------------------------------------
// createParameterLayout — mixed types based on ControlStyle
// -----------------------------------------------------------------------
juce::AudioProcessorValueTreeState::ParameterLayout
JT8000ControllerProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;
    params.reserve(kNumParams);

    for (int i = 0; i < kNumParams; ++i)
    {
        const auto& p = kAllParams[i];

        if (isChoiceParam(p))
        {
            // Build StringArray from the enum names
            juce::StringArray choices;
            for (int c = 0; c < p.enumCount; ++c)
                choices.add(p.enumNames[c]);

            params.push_back(std::make_unique<juce::AudioParameterChoice>(
                juce::ParameterID { p.id, 1 }, p.name, choices, p.defVal));
        }
        else
        {
            // Continuous 0-127 integer
            params.push_back(std::make_unique<juce::AudioParameterInt>(
                juce::ParameterID { p.id, 1 }, p.name, 0, 127, p.defVal));
        }
    }
    return { params.begin(), params.end() };
}

// -----------------------------------------------------------------------
// createEditor
// -----------------------------------------------------------------------
juce::AudioProcessorEditor* JT8000ControllerProcessor::createEditor()
{
    return new JT8000ControllerEditor(*this);
}

// -----------------------------------------------------------------------
// processBlock — drain the FIFO into the MIDI output buffer
// -----------------------------------------------------------------------
void JT8000ControllerProcessor::processBlock(juce::AudioBuffer<float>& buffer,
                                              juce::MidiBuffer& midiMessages)
{
    for (int ch = getTotalNumInputChannels(); ch < getTotalNumOutputChannels(); ++ch)
        buffer.clear(ch, 0, buffer.getNumSamples());

    const int ready = fifo.getNumReady();
    if (ready > 0)
    {
        int s1, sz1, s2, sz2;
        fifo.prepareToRead(ready, s1, sz1, s2, sz2);
        const int ch = juce::jlimit(1, 16, midiChannel.load());

        for (int i = s1; i < s1 + sz1; ++i)
            midiMessages.addEvent(juce::MidiMessage::controllerEvent(
                ch, messageBuffer[i].cc, messageBuffer[i].value), 0);
        for (int i = s2; i < s2 + sz2; ++i)
            midiMessages.addEvent(juce::MidiMessage::controllerEvent(
                ch, messageBuffer[i].cc, messageBuffer[i].value), 0);

        fifo.finishedRead(ready);
    }
}

// -----------------------------------------------------------------------
// parameterChanged — convert to CC value and send
//
// For choice params: newValue is the choice index (0..N-1 as float).
//   Convert to CC bucket midpoint using choiceIndexToCC().
// For int params: newValue is the raw CC value (0..127 as float).
// -----------------------------------------------------------------------
void JT8000ControllerProcessor::parameterChanged(const juce::String& id, float newValue)
{
    const CCParam* p = findParamByID(id);
    if (!p) return;

    int ccVal;
    if (isChoiceParam(*p))
        ccVal = choiceIndexToCC(juce::roundToInt(newValue), p->enumCount);
    else
        ccVal = juce::roundToInt(newValue);

    sendCC(p->cc, ccVal);
}

// -----------------------------------------------------------------------
// sendCC — direct MIDI out (standalone) + FIFO (DAW)
// -----------------------------------------------------------------------
void JT8000ControllerProcessor::sendCC(int cc, int value)
{
    const uint8_t ccByte  = static_cast<uint8_t>(juce::jlimit(0, 127, cc));
    const uint8_t valByte = static_cast<uint8_t>(juce::jlimit(0, 127, value));

    {
        const juce::ScopedLock sl(midiOutLock);
        if (directMidiOut != nullptr)
        {
            const int ch = juce::jlimit(1, 16, midiChannel.load());
            directMidiOut->sendMessageNow(
                juce::MidiMessage::controllerEvent(ch, ccByte, valByte));
        }
    }

    int s1, sz1, s2, sz2;
    fifo.prepareToWrite(1, s1, sz1, s2, sz2);
    if (sz1 > 0)
        messageBuffer[s1] = { ccByte, valByte };
    fifo.finishedWrite(sz1 + sz2);
}

// -----------------------------------------------------------------------
// sendAllCCs — push entire state to hardware
// -----------------------------------------------------------------------
void JT8000ControllerProcessor::sendAllCCs()
{
    for (int i = 0; i < kNumParams; ++i)
    {
        const auto& p = kAllParams[i];
        if (auto* val = apvts.getRawParameterValue(p.id))
        {
            int ccVal;
            if (isChoiceParam(p))
                ccVal = choiceIndexToCC(juce::roundToInt(val->load()), p.enumCount);
            else
                ccVal = juce::roundToInt(val->load());
            sendCC(p.cc, ccVal);
        }
    }
}

void JT8000ControllerProcessor::setMidiOutput(std::unique_ptr<juce::MidiOutput> output)
{
    const juce::ScopedLock sl(midiOutLock);
    directMidiOut = std::move(output);
}

void JT8000ControllerProcessor::getStateInformation(juce::MemoryBlock& dest)
{
    if (auto xml = apvts.copyState().createXml())
        copyXmlToBinary(*xml, dest);
}

void JT8000ControllerProcessor::setStateInformation(const void* data, int size)
{
    if (auto xml = getXmlFromBinary(data, size))
        if (xml->hasTagName(apvts.state.getType()))
        {
            apvts.replaceState(juce::ValueTree::fromXml(*xml));
            sendAllCCs();
        }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new JT8000ControllerProcessor();
}
