/*
 * PluginEditor.h — JT-8000 Controller Main Window
 *
 * Owns the JT8000LookAndFeel instance and passes it to all SectionComponents.
 * Header bar with MIDI routing, SYX import, patch save/load, expand/collapse.
 */

#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_audio_devices/juce_audio_devices.h>
#include <juce_gui_extra/juce_gui_extra.h>
#include "PluginProcessor.h"
#include "SectionComponent.h"
#include "JT8000LookAndFeel.h"
#include "JP8000SyxImporter.h"

class JT8000ControllerEditor : public juce::AudioProcessorEditor
{
public:
    JT8000ControllerEditor(JT8000ControllerProcessor&);
    ~JT8000ControllerEditor() override = default;

    void paint(juce::Graphics& g) override;
    void resized() override;

private:
    JT8000ControllerProcessor& _proc;
    JT8000LookAndFeel _lnf;

    juce::Label     _titleLabel;
    juce::ComboBox  _midiChSelector;
    juce::ComboBox  _midiOutSelector;
    juce::TextButton _sendAllBtn   { "Send All" };
    juce::TextButton _loadSyxBtn   { "Load SYX" };
    juce::TextButton _savePatchBtn { "Save" };
    juce::TextButton _loadPatchBtn { "Load" };
    juce::TextButton _expandBtn    { "Expand" };
    juce::TextButton _collapseBtn  { "Collapse" };

    juce::Viewport  _viewport;
    juce::Component _contentPanel;
    juce::OwnedArray<SectionComponent> _sections;

    void buildSections();
    void layoutSections();
    void refreshMidiOutputList();

    void loadSyxFile();
    void showPatchPicker(const juce::String& fileName);
    std::unique_ptr<juce::FileChooser> _fileChooser;
    juce::MemoryBlock _syxBuffer;
    std::vector<JP8000SyxImporter::Patch> _syxPatches;

    void savePatchFile();
    void loadPatchFile();

    static constexpr int kHeaderHeight = 44;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(JT8000ControllerEditor)
};
