/*
 * JP8000SyxImporter.h — JP-8000/8080 SysEx Import for JUCE Plugin
 *
 * Parses .syx and .mid files, extracts JP-8000 patches, and loads them
 * into the JUCE AudioProcessorValueTreeState by setting each parameter
 * to the transformed CC value.
 *
 * Mirrors JP8000SyxMap.h and the HTML editor's SYX_SLOTS table exactly.
 * Uses raw CC numbers (from CCDefinitions.h) instead of the Arduino-dependent
 * CC:: namespace, so this file has zero Arduino/Teensy dependencies.
 *
 * USAGE:
 *   auto patches = JP8000SyxImporter::parseFile(fileData, fileSize, isMidi);
 *   JP8000SyxImporter::loadPatch(apvts, patches[selectedIndex]);
 *   processor.sendAllCCs();  // Push to hardware
 */

#pragma once
#include <juce_core/juce_core.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include "CCDefinitions.h"

namespace JP8000SyxImporter
{

// =========================================================================
// Parsed patch — lightweight reference into the original file buffer
// =========================================================================
struct Patch
{
    juce::String name;
    int          dataOffset;   // Offset into the source buffer
    int          dataLen;      // Length of the patch data block
    const uint8_t* srcBuffer;  // Pointer to the original file data (must stay alive)
};

// =========================================================================
// Waveform / enum remap tables
// Mirrors JP8000SyxMap.h exactly — using raw CC midpoint values
// =========================================================================

// JP OSC1: 0=SuperSaw,1=TWM,2=Feedback,3=Noise,4=Pulse,5=Saw,6=Triangle
static constexpr uint8_t kOsc1WaveMap[] = { 123, 77, 13, 68, 113, 86, 31 };
// JP OSC2: 0=Pulse,1=Triangle,2=Saw,3=Noise
static constexpr uint8_t kOsc2WaveMap[] = { 113, 31, 86, 68 };
// JP LFO1: 0=Tri,1=Saw,2=Sqr,3=S&H (same ordering as JT)
static constexpr uint8_t kLfo1WaveMap[] = { 0, 1, 2, 3 };
// JP Filter: 0=HPF,1=BPF,2=LPF → JT: 2=HPF,1=BPF,0=LPF
static constexpr uint8_t kFilterTypeMap[] = { 2, 1, 0 };
// JP MFX: 0-12 → JT FX_MOD_EFFECT
static constexpr uint8_t kMfxTypeMap[] = { 10,10,0,1,3, 0,0,0, 0,0,0,0,0 };
// JP Delay: 0-4 → JT FX_JPFX_DELAY_EFFECT
static constexpr uint8_t kDelayTypeMap[] = { 2, 0, 3, 1, 1 };

// =========================================================================
// Safe defaults for JT-exclusive parameters (CC, value)
// Sent before each patch load to reset params that have no JP-8000 source
// =========================================================================
struct DefaultCC { int cc; int val; };
static constexpr DefaultCC kDefaults[] = {
    {113, 0},   // FILTER_ENGINE → OBXa
    {115, 0},   // VA_FILTER_TYPE
    {111, 0},   // FILTER_OBXA_MULTIMODE
    {114, 0},   // FILTER_OBXA_XPANDER_MODE
    {117, 0},   // FILTER_OBXA_RES_MOD_DEPTH
    { 84, 64},  // FILTER_OCTAVE_CONTROL
    { 16, 0},   // FX_DRIVE
    { 94,127},  // FX_REVERB_BYPASS (off)
    { 74,127},  // FX_DRY_MIX (full)
    { 76,127},  // FX_JPFX_MIX (full)
    { 59, 0},   // NOISE_MIX
    { 58, 0},   // SUB_MIX
    { 15, 64},  // UNISON_DETUNE
    { 67, 0},   // PITCH_ENV_SUSTAIN
    { 68, 0},   // PITCH_ENV_RELEASE
    { 35, 0},   // LFO1_PWM_DEPTH
    { 40, 0},   // LFO2_PWM_DEPTH
    { 55, 64},  // LFO1_DEPTH
    { 52, 64},  // LFO2_DEPTH
    { 53, 0},   // LFO2_DESTINATION
    {  2, 0},   // SEQ_ENABLE (off)
};

// =========================================================================
// Slot table — maps JP-8000 SysEx offset → JT CC with transform
// =========================================================================
enum class Xform { Direct, Bool127, Signed64, Signed64ToUni,
                   Osc1Wave, Osc2Wave, Lfo1Wave, FilterType,
                   MfxType, DelayType, Osc2Range, Osc2Fine, MonoMode };

struct Slot { uint8_t offset; int cc; Xform xf; };

static constexpr Slot kSlots[] = {
    // LFO / Modulation
    { 0x10,  62, Xform::Lfo1Wave     },  // LFO1_WAVEFORM
    { 0x11,  54, Xform::Direct       },  // LFO1_FREQ
    { 0x12,  37, Xform::Direct       },  // LFO1_DELAY (JP "Fade")
    { 0x13,  51, Xform::Direct       },  // LFO2_FREQ
    { 0x15,  91, Xform::Bool127      },  // RING1_MIX
    { 0x17,  47, Xform::Signed64     },  // OSC_MIX_BALANCE
    { 0x18,  56, Xform::Direct       },  // LFO1_DESTINATION
    { 0x19,  33, Xform::Signed64ToUni},  // LFO1_PITCH_DEPTH
    { 0x1A,  38, Xform::Signed64ToUni},  // LFO2_PITCH_DEPTH
    { 0x1B,  69, Xform::Signed64     },  // PITCH_ENV_DEPTH
    { 0x1C,  65, Xform::Direct       },  // PITCH_ENV_ATTACK
    { 0x1D,  66, Xform::Direct       },  // PITCH_ENV_DECAY
    // Oscillators
    { 0x1E,  21, Xform::Osc1Wave     },  // OSC1_WAVE
    { 0x21,  22, Xform::Osc2Wave     },  // OSC2_WAVE
    { 0x23,  42, Xform::Osc2Range    },  // OSC2_PITCH_OFFSET
    { 0x24,  46, Xform::Osc2Fine     },  // OSC2_FINE_TUNE
    // Filter
    { 0x27, 112, Xform::FilterType   },  // FILTER_MODE
    { 0x29,  23, Xform::Direct       },  // FILTER_CUTOFF
    { 0x2A,  24, Xform::Direct       },  // FILTER_RESONANCE
    { 0x2B,  50, Xform::Signed64     },  // FILTER_KEY_TRACK
    { 0x2C,  34, Xform::Signed64ToUni},  // LFO1_FILTER_DEPTH
    { 0x2D,  39, Xform::Signed64ToUni},  // LFO2_FILTER_DEPTH
    { 0x2E,  48, Xform::Signed64     },  // FILTER_ENV_AMOUNT
    // Filter Envelope
    { 0x2F,  29, Xform::Direct       },  // FILTER_ENV_ATTACK
    { 0x30,  30, Xform::Direct       },  // FILTER_ENV_DECAY
    { 0x31,  31, Xform::Direct       },  // FILTER_ENV_SUSTAIN
    { 0x32,  32, Xform::Direct       },  // FILTER_ENV_RELEASE
    // Amp
    { 0x33,  90, Xform::Direct       },  // AMP_MOD_FIXED_LEVEL
    { 0x34,  36, Xform::Signed64ToUni},  // LFO1_AMP_DEPTH
    { 0x35,  57, Xform::Signed64ToUni},  // LFO2_AMP_DEPTH
    // Amp Envelope
    { 0x36,  25, Xform::Direct       },  // AMP_ATTACK
    { 0x37,  26, Xform::Direct       },  // AMP_DECAY
    { 0x38,  27, Xform::Direct       },  // AMP_SUSTAIN
    { 0x39,  28, Xform::Direct       },  // AMP_RELEASE
    // Tone / Effects
    { 0x3B,  99, Xform::Signed64     },  // FX_BASS_GAIN
    { 0x3C, 100, Xform::Signed64     },  // FX_TREBLE_GAIN
    { 0x3D, 103, Xform::MfxType      },  // FX_MOD_EFFECT
    { 0x3E, 104, Xform::Direct       },  // FX_MOD_MIX
    { 0x3F, 107, Xform::DelayType    },  // FX_JPFX_DELAY_EFFECT
    { 0x40, 110, Xform::Direct       },  // FX_JPFX_DELAY_TIME
    { 0x41, 109, Xform::Direct       },  // FX_JPFX_DELAY_FEEDBACK
    { 0x42, 108, Xform::Direct       },  // FX_JPFX_DELAY_MIX
    // Performance
    { 0x43, 127, Xform::Direct       },  // PITCH_BEND_RANGE
    { 0x45,  81, Xform::Bool127      },  // GLIDE_ENABLE
    { 0x46,  82, Xform::Direct       },  // GLIDE_TIME
    { 0x47,  14, Xform::MonoMode     },  // POLY_MODE
};

// =========================================================================
// Transform helper
// =========================================================================
inline int clamp7(int v) { return v < 0 ? 0 : (v > 127 ? 127 : v); }

inline int applyTransform(Xform xf, uint8_t raw)
{
    switch (xf)
    {
        case Xform::Direct:        return raw;
        case Xform::Bool127:       return raw ? 127 : 0;
        case Xform::Signed64:      return raw;
        case Xform::Signed64ToUni: return clamp7(std::abs((int)raw - 64) * 2);
        case Xform::Osc1Wave:     return (raw < 7)  ? kOsc1WaveMap[raw]   : 86;
        case Xform::Osc2Wave:     return (raw < 4)  ? kOsc2WaveMap[raw]   : 86;
        case Xform::Lfo1Wave:     return (raw < 4)  ? kLfo1WaveMap[raw]   : 0;
        case Xform::FilterType:   return (raw < 3)  ? kFilterTypeMap[raw]  : 0;
        case Xform::MfxType:      return (raw < 13) ? kMfxTypeMap[raw]    : 0;
        case Xform::DelayType:    return (raw < 5)  ? kDelayTypeMap[raw]  : 0;
        case Xform::Osc2Range:    return clamp7((int)(raw * 127 + 25) / 50);
        case Xform::Osc2Fine:     return clamp7((int)(raw * 127 + 50) / 100);
        case Xform::MonoMode:     return (raw == 0) ? 0 : 64;
    }
    return raw;
}

// =========================================================================
// Context-dependent OSC control dispatch (mirrors JP8000SyxMap.h)
// Returns the CC number to target, or 0 to skip.
// =========================================================================
inline int osc1Ctrl1CC(uint8_t wave) { switch(wave){ case 0:return 77; case 1:case 2:case 4:case 6:return 60; default:return 0; } }
inline int osc1Ctrl2CC(uint8_t wave) { switch(wave){ case 0:return 78; case 1:case 2:return 123; default:return 0; } }
inline int osc2Ctrl1CC(uint8_t wave) { switch(wave){ case 0:case 1:return 61; default:return 0; } }
inline int osc2Ctrl2CC(uint8_t wave) { (void)wave; return 0; }

// =========================================================================
// Set an APVTS parameter by CC number
// =========================================================================
inline void setParamByCC(juce::AudioProcessorValueTreeState& apvts, int cc, int value)
{
    const CCParam* p = findParamByCC(cc);
    if (!p) return;
    if (auto* param = apvts.getRawParameterValue(p->id))
    {
        // Use beginChangeGesture/endChangeGesture for proper undo/automation
        if (auto* pi = apvts.getParameter(p->id))
        {
            pi->beginChangeGesture();
            pi->setValueNotifyingHost(pi->convertTo0to1((float)juce::jlimit(0, 127, value)));
            pi->endChangeGesture();
        }
    }
}

// =========================================================================
// Parse .syx file → vector of Patch
// =========================================================================
inline std::vector<Patch> parseSyxBuffer(const uint8_t* buf, size_t len)
{
    std::vector<Patch> patches;
    size_t i = 0;
    while (i < len)
    {
        if (buf[i] != 0xF0) { ++i; continue; }
        size_t f0 = i; ++i;
        while (i < len && buf[i] != 0xF7) ++i;
        if (i >= len) break;

        size_t msgStart = f0 + 1;
        size_t msgLen = i - msgStart;

        // Validate Roland DT1: 41 xx 00 06 12
        if (msgLen >= 20 && buf[msgStart] == 0x41 &&
            buf[msgStart+2] == 0x00 && buf[msgStart+3] == 0x06 &&
            buf[msgStart+4] == 0x12)
        {
            int dataOff = (int)(msgStart + 9);
            int dataLen = (int)(msgLen - 9 - 1); // exclude checksum
            if (dataLen >= 74)
            {
                // Extract name
                juce::String name;
                for (int j = 0; j < 16 && (dataOff + j) < (int)len; ++j)
                {
                    char c = (char)buf[dataOff + j];
                    name += (c >= 0x20 && c <= 0x7E) ? juce::String::charToString(c)
                                                      : " ";
                }
                patches.push_back({ name.trim(), dataOff, dataLen, buf });
            }
        }
        ++i;
    }
    return patches;
}

// =========================================================================
// Parse .mid file → vector of Patch
// =========================================================================
inline uint32_t readVLQ(const uint8_t* buf, size_t len, size_t& pos)
{
    uint32_t val = 0;
    while (pos < len)
    {
        uint8_t b = buf[pos++];
        val = (val << 7) | (b & 0x7F);
        if (!(b & 0x80)) break;
    }
    return val;
}

inline std::vector<Patch> parseMidBuffer(const uint8_t* buf, size_t len)
{
    std::vector<Patch> patches;
    if (len < 14 || buf[0] != 'M' || buf[1] != 'T' || buf[2] != 'h' || buf[3] != 'd')
        return patches;

    uint32_t headerLen = ((uint32_t)buf[4]<<24)|((uint32_t)buf[5]<<16)|
                         ((uint32_t)buf[6]<<8)|(uint32_t)buf[7];
    uint16_t nTracks = ((uint16_t)buf[10]<<8)|buf[11];
    size_t pos = 8 + headerLen;

    for (uint16_t trk = 0; trk < nTracks && pos + 8 <= len; ++trk)
    {
        if (buf[pos]!='M'||buf[pos+1]!='T'||buf[pos+2]!='r'||buf[pos+3]!='k') break;
        uint32_t trkLen = ((uint32_t)buf[pos+4]<<24)|((uint32_t)buf[pos+5]<<16)|
                          ((uint32_t)buf[pos+6]<<8)|(uint32_t)buf[pos+7];
        size_t trkEnd = pos + 8 + trkLen;
        size_t p = pos + 8;

        while (p < trkEnd && p < len)
        {
            readVLQ(buf, trkEnd, p);
            if (p >= trkEnd) break;
            uint8_t status = buf[p];

            if (status == 0xF0)
            {
                ++p;
                uint32_t msgLen = readVLQ(buf, trkEnd, p);
                size_t contentLen = msgLen > 0 ? msgLen - 1 : 0;

                if (contentLen >= 20 && p + msgLen <= len &&
                    buf[p] == 0x41 && buf[p+2] == 0x00 && buf[p+3] == 0x06 && buf[p+4] == 0x12)
                {
                    int dataOff = (int)(p + 9);
                    int dataLen = (int)(contentLen - 9 - 1);
                    if (dataLen >= 74)
                    {
                        juce::String name;
                        for (int j = 0; j < 16 && (dataOff + j) < (int)len; ++j)
                        {
                            char c = (char)buf[dataOff + j];
                            name += (c >= 0x20 && c <= 0x7E) ? juce::String::charToString(c) : " ";
                        }
                        patches.push_back({ name.trim(), dataOff, dataLen, buf });
                    }
                }
                p += msgLen;
            }
            else if (status == 0xFF)
            {
                p += 2;
                uint32_t metaLen = readVLQ(buf, trkEnd, p);
                p += metaLen;
            }
            else if (status >= 0x80)
            {
                ++p;
                if (status >= 0xC0 && status < 0xE0) p += 1;
                else if ((status >= 0x80 && status < 0xC0) || (status >= 0xE0 && status < 0xF0)) p += 2;
            }
            else { ++p; }
        }
        pos = trkEnd;
    }
    return patches;
}

// =========================================================================
// parseFile — auto-detect format from extension or content
// =========================================================================
inline std::vector<Patch> parseFile(const uint8_t* buf, size_t len, bool isMidi)
{
    return isMidi ? parseMidBuffer(buf, len) : parseSyxBuffer(buf, len);
}

// =========================================================================
// loadPatch — apply a parsed patch to the APVTS
// Mirrors the HTML editor's loadSyxPatch() and the firmware's
// JP8000SyxLoader::loadPatchData() exactly.
// =========================================================================
inline void loadPatch(juce::AudioProcessorValueTreeState& apvts, const Patch& patch)
{
    const uint8_t* buf = patch.srcBuffer;
    auto d = [&](int off) -> uint8_t {
        int idx = patch.dataOffset + off;
        return (idx >= 0 && idx < patch.dataOffset + patch.dataLen) ? buf[idx] : 0;
    };

    // Step 1: Safe defaults
    for (const auto& def : kDefaults)
        setParamByCC(apvts, def.cc, def.val);

    // Step 2: Read waveforms for context dispatch
    uint8_t osc1Wave = d(0x1E);
    uint8_t osc2Wave = d(0x21);
    uint8_t mfxType  = d(0x3D);

    // Step 3: Main slot table
    for (const auto& slot : kSlots)
    {
        uint8_t raw = d(slot.offset);
        int val = applyTransform(slot.xf, raw);
        setParamByCC(apvts, slot.cc, val);
    }

    // Step 4: Context-dependent OSC controls
    if (int cc = osc1Ctrl1CC(osc1Wave)) setParamByCC(apvts, cc, d(0x1F));
    if (int cc = osc1Ctrl2CC(osc1Wave)) setParamByCC(apvts, cc, d(0x20));
    if (int cc = osc2Ctrl1CC(osc2Wave)) setParamByCC(apvts, cc, d(0x25));
    if (int cc = osc2Ctrl2CC(osc2Wave)) setParamByCC(apvts, cc, d(0x26));

    // Step 5: MFX drive (types 8-12)
    if (mfxType >= 8 && mfxType <= 12)
    {
        int driveVal = juce::jmin(127, 32 + (mfxType - 8) * 24);
        setParamByCC(apvts, 16, driveVal);   // FX_DRIVE
        setParamByCC(apvts, 103, 0);          // FX_MOD_EFFECT off
    }

    // Step 6: MFX short delay (types 5-7)
    if (mfxType >= 5 && mfxType <= 7)
    {
        setParamByCC(apvts, 107, 0);          // FX_JPFX_DELAY_EFFECT = MONO_SHORT
        setParamByCC(apvts, 108, d(0x3E));    // FX_JPFX_DELAY_MIX = MFX level
        setParamByCC(apvts, 103, 0);          // FX_MOD_EFFECT off
    }

    // Step 7: Super Chorus Fast rate boost
    if (mfxType == 1)
        setParamByCC(apvts, 105, 100);        // FX_MOD_RATE high
}

} // namespace JP8000SyxImporter
